@echo off
setlocal
pushd "%~dp0ReiPatcher"
if errorlevel 1 (
  echo ReiPatcher klasoru bulunamadi. ZIP'i BioEden.exe'nin yanina cikardin mi?
  pause
  exit /b 1
)
ReiPatcher.exe -c "BioEden.ini"
set "result=%ERRORLEVEL%"
popd
exit /b %result%
