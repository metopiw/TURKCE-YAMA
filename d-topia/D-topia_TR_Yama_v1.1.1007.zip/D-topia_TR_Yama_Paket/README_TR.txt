D-TOPIA TÜRKÇE YAMA

UYUMLU OYUN SÜRÜMÜ
- D-topia 1.1.1007

ÇEVİRMEN
- mertpivvo

KURULUM
1. Oyunun kurulu olduğu klasördeki D-topia_Data klasörünü açın.
2. Orijinal sharedassets1.assets dosyasının yedeğini alın.
3. Paketteki D-topia_Data/sharedassets1.assets dosyasını oyunun aynı klasörüne kopyalayıp mevcut dosyanın üzerine yazın.
4. Oyunda dil olarak Deutsch / German seçin. Almanca dil yuvası Türkçe ile değiştirilmiştir.

KALDIRMA
Yedeklediğiniz orijinal sharedassets1.assets dosyasını geri koyun veya oyun dosyalarını doğrulayın.

TEKNİK BİLGİ
- İngilizce kaynak ve diğer yabancı diller değiştirilmedi.
- Yalnızca mess_database_de (bu build'de Path ID 6377) Türkçeleştirildi.
- İngilizce kaynakta 8.976 kayıt / 8.502 benzersiz metin işlendi.
- İngilizce kaynak yaklaşık 76.699 kelimedir.
- Ana menüde “AYARLAR - mertpivvo” imzası görünür.
- Önceki FPS satırı imzası kaldırıldı; “En Yüksek Kare Hızı” çevirisi geri getirildi.
- Son repack doğrulamasında 8.905 nesneden yalnızca Path ID 6377 değişti.
- İngilizce veritabanı Path ID 6378 byte düzeyinde aynı kaldı.
- Oyun içi çalışırlık kullanıcı tarafından doğrulandı.

EK DOSYALAR
- Ek_Dosyalar/translations_tr.json: Benzersiz çeviri eşlemeleri
- Ek_Dosyalar/signature_override.json: Menü imzası key override'ı
- Unity_MonoBehaviour_Lokalizasyon_Rehberi.md: Benzer Unity/IL2CPP oyunları için tespit, unpack ve repack rehberi
- unity_localization_profile_dtopia.json: Yapay zeka agent'i/uygulama veri tabanı için makine okunabilir profil
