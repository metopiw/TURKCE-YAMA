@echo off
chcp 65001 >nul
title BLACKWOOD Turkce Yama Kaldirma
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0kaldir.ps1"
echo.
pause
