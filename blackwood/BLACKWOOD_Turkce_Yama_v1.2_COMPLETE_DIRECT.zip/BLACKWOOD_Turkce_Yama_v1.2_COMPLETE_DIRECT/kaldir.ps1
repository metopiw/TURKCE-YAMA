param([string]$GameRoot)

$ErrorActionPreference = 'Stop'
$gameRoot = if ($GameRoot) { $GameRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$dataDir = Join-Path $gameRoot 'Blackwood_Data'

if (-not (Test-Path -LiteralPath (Join-Path $gameRoot 'Blackwood.exe'))) {
    Write-Host '[HATA] Dosyalari Blackwood.exe dosyasinin yanina cikartin.' -ForegroundColor Red
    exit 1
}

function Clear-ReadOnly([string]$Path) {
    if ([System.IO.File]::Exists($Path)) {
        $attributes = [System.IO.File]::GetAttributes($Path)
        if (($attributes -band [System.IO.FileAttributes]::ReadOnly) -ne 0) {
            [System.IO.File]::SetAttributes($Path, ($attributes -band (-bnot [System.IO.FileAttributes]::ReadOnly)))
        }
    }
}

$backups = @(Get-ChildItem -LiteralPath $dataDir -File -Filter '*.bak')
if ($backups.Count -eq 0) {
    Write-Host 'Geri yuklenecek yedek bulunamadi.' -ForegroundColor Yellow
    exit 0
}

foreach ($backup in $backups) {
    $target = $backup.FullName.Substring(0, $backup.FullName.Length - 4)
    $temp = $target + '.patching.tmp'
    Clear-ReadOnly $backup.FullName
    Clear-ReadOnly $target
    if ([System.IO.File]::Exists($temp)) {
        Clear-ReadOnly $temp
        [System.IO.File]::Delete($temp)
    }
    [System.IO.File]::Copy($backup.FullName, $target, $true)
    Clear-ReadOnly $target
    Write-Host ('[GERI YUKLENDI] ' + [System.IO.Path]::GetFileName($target))
}

Write-Host ''
Write-Host ('Turkce yama kaldirildi. {0} ozgun dosya geri yuklendi.' -f $backups.Count) -ForegroundColor Green
