@echo off
chcp 65001 >nul
title BLACKWOOD Turkce Yama v1.1 FIX
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0kurulum.ps1"
echo.
pause
