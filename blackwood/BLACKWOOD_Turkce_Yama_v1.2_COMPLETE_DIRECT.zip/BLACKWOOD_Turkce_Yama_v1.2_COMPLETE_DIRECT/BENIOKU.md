# BLACKWOOD Türkçe Yama v1.2

Çeviri: mertpivvo

1. ZIP dosyasını oyun klasörüne çıkarın.
2. Oyunu kapatın.
3. `KURULUM.bat` dosyasını çalıştırın.
4. Kurulum bitince oyunu başlatın.

Kurulum, mevcut `.bak` yedeğini kullanır. Kaldırmak için `KALDIR.bat`ı çalıştırın.
