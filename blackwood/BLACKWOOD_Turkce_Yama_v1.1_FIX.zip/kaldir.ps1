param([string]$GameRoot)

$ErrorActionPreference = 'Stop'
$gameRoot = if ($GameRoot) { $GameRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$dataDir = Join-Path $gameRoot 'Blackwood_Data'

if (-not (Test-Path -LiteralPath (Join-Path $gameRoot 'Blackwood.exe'))) {
    Write-Host '[HATA] Dosyalari Blackwood.exe dosyasinin yanina cikartin.' -ForegroundColor Red
    exit 1
}

$backups = @(Get-ChildItem -LiteralPath $dataDir -File -Filter '*.bak')
if ($backups.Count -eq 0) {
    Write-Host 'Geri yuklenecek yedek bulunamadi.' -ForegroundColor Yellow
    exit 0
}

foreach ($backup in $backups) {
    $target = $backup.FullName.Substring(0, $backup.FullName.Length - 4)
    [System.IO.File]::Copy($backup.FullName, $target, $true)
    Write-Host ('[GERI YUKLENDI] ' + [System.IO.Path]::GetFileName($target))
}

Write-Host ''
Write-Host ('Turkce yama kaldirildi. {0} ozgun dosya geri yuklendi.' -f $backups.Count) -ForegroundColor Green
