param([string]$GameRoot, [switch]$SkipProcessCheck)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2

$gameRoot = if ($GameRoot) { $GameRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$dataDir = Join-Path $gameRoot 'Blackwood_Data'
$patchDir = Join-Path $gameRoot 'yama'
$indexPath = Join-Path $patchDir 'patch_index.json'
$blobPath = Join-Path $patchDir 'patch_blob.bin'

if (-not (Test-Path -LiteralPath (Join-Path $gameRoot 'Blackwood.exe'))) {
    Write-Host '[HATA] Dosyalari Blackwood.exe dosyasinin yanina cikartin.' -ForegroundColor Red
    exit 1
}
if (-not (Test-Path -LiteralPath $indexPath) -or -not (Test-Path -LiteralPath $blobPath)) {
    Write-Host '[HATA] yama klasoru veya yama verileri eksik.' -ForegroundColor Red
    exit 1
}
if (-not $SkipProcessCheck -and (Get-Process -Name 'Blackwood' -ErrorAction SilentlyContinue)) {
    Write-Host '[HATA] Kurulumdan once BLACKWOOD oyununu kapatin.' -ForegroundColor Red
    exit 1
}

$source = @'
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

public static class BlackwoodPatch
{
    private sealed class Obj
    {
        public long Pid, Offset, NewOffset;
        public int Size, NewSize, TypeId, OffsetPos, SizePos;
    }

    private sealed class Asset
    {
        public byte[] Raw;
        public int Version, DataOffset;
        public List<Obj> Objects = new List<Obj>();
    }

    private static int I32(byte[] d, int p) { return BitConverter.ToInt32(d, p); }
    private static long I64(byte[] d, int p) { return BitConverter.ToInt64(d, p); }
    private static uint U32BE(byte[] d, int p) { return (uint)(d[p] << 24 | d[p+1] << 16 | d[p+2] << 8 | d[p+3]); }
    private static ulong U64BE(byte[] d, int p)
    {
        ulong v = 0; for (int i = 0; i < 8; i++) v = (v << 8) | d[p+i]; return v;
    }
    private static void W32(byte[] d, int p, int v) { byte[] b = BitConverter.GetBytes(v); Buffer.BlockCopy(b, 0, d, p, 4); }
    private static void W64(byte[] d, int p, long v) { byte[] b = BitConverter.GetBytes(v); Buffer.BlockCopy(b, 0, d, p, 8); }
    private static void W64BE(byte[] d, int p, long v)
    {
        ulong n = (ulong)v; for (int i = 7; i >= 0; i--) { d[p+i] = (byte)n; n >>= 8; }
    }

    private static int CStringEnd(byte[] d, int p) { while (d[p] != 0) p++; return p + 1; }

    private static int SkipType(byte[] d, int p, int version, bool tree)
    {
        int cls = I32(d, p); p += 4;
        if (version >= 16) p += 1;
        if (version >= 17) p += 2;
        if (version >= 13) {
            bool cond = (version < 16 && cls < 0) || (version >= 16 && cls == 114);
            if (cond) p += 16;
            p += 16;
        }
        if (tree) {
            int count = I32(d, p), buffer = I32(d, p + 4);
            int nodeSize = version >= 19 ? 24 : 32;
            p += 8 + nodeSize * count + buffer;
            if (version >= 21) { int deps = I32(d, p); p += 4 + 4 * deps; }
        }
        return p;
    }

    private static Asset Parse(byte[] d)
    {
        Asset a = new Asset(); a.Raw = d; a.Version = (int)U32BE(d, 8);
        a.DataOffset = a.Version >= 22 ? checked((int)U64BE(d, 32)) : checked((int)U32BE(d, 12));
        int p = CStringEnd(d, 48) + 4;
        bool tree = d[p++] != 0;
        int typeCount = I32(d, p); p += 4;
        for (int i = 0; i < typeCount; i++) p = SkipType(d, p, a.Version, tree);
        int objectCount = I32(d, p); p += 4;
        for (int i = 0; i < objectCount; i++) {
            p = (p + 3) & ~3;
            Obj o = new Obj();
            o.Pid = I64(d, p); p += 8;
            o.OffsetPos = p;
            o.Offset = a.Version >= 22 ? I64(d, p) : (long)BitConverter.ToUInt32(d, p);
            p += a.Version >= 22 ? 8 : 4;
            o.SizePos = p; o.Size = I32(d, p); p += 4;
            o.TypeId = I32(d, p); p += 4;
            a.Objects.Add(o);
        }
        return a;
    }

    private static bool TextAt(byte[] d, int p, out int size, out byte[] raw)
    {
        size = 0; raw = null;
        if (p < 0 || p + 4 > d.Length) return false;
        uint n = BitConverter.ToUInt32(d, p);
        if (n > d.Length - p - 4 || n > Int32.MaxValue) return false;
        size = (int)n; raw = new byte[size]; Buffer.BlockCopy(d, p + 4, raw, 0, size);
        try {
            string s = new UTF8Encoding(false, true).GetString(raw);
            if (s.Length > 0) {
                int printable = 0;
                foreach (char c in s) if (!Char.IsControl(c) || Char.IsWhiteSpace(c)) printable++;
                if (s.IndexOf('\0') >= 0 || printable * 100 < s.Length * 85) return false;
            }
            return true;
        } catch { return false; }
    }

    private static byte[] RepairObject(byte[] original, byte[] patched)
    {
        int oi = 0, pi = 0;
        MemoryStream output = new MemoryStream();
        while (oi < original.Length && pi < patched.Length) {
            int run = 0, limit = Math.Min(original.Length - oi, patched.Length - pi);
            while (run < limit && original[oi + run] == patched[pi + run]) run++;
            if (run == limit) {
                output.Write(patched, pi, patched.Length - pi); oi = original.Length; pi = patched.Length; break;
            }
            int diffO = oi + run, diffP = pi + run;
            int soFound = -1, spFound = -1, oldSize = 0, newSize = 0, oldPad = 0;
            byte[] newRaw = null;
            List<int[]> candidates = new List<int[]>();
            for (int back = 0; back < 4; back++) {
                int so = diffO - back, sp = diffP - back;
                if (so >= oi && (so & 3) == 0) candidates.Add(new int[] { so, sp });
            }
            for (int so = diffO & ~3; so >= oi; so -= 4) {
                int os; byte[] oraw;
                if (TextAt(original, so, out os, out oraw) && so + 4 <= diffO && diffO < so + 4 + os)
                    candidates.Add(new int[] { so, pi + (so - oi) });
            }
            foreach (int[] c in candidates) {
                int os, ns; byte[] oraw, nraw;
                if (!TextAt(original, c[0], out os, out oraw) || !TextAt(patched, c[1], out ns, out nraw)) continue;
                int op = (-os) & 3;
                if (c[0] + 4 + os + op > original.Length || c[1] + 4 + ns + op > patched.Length) continue;
                soFound = c[0]; spFound = c[1]; oldSize = os; newSize = ns; newRaw = nraw; oldPad = op; break;
            }
            if (soFound < 0) {
                if (original.Length - oi == patched.Length - pi) {
                    output.Write(patched, pi, patched.Length - pi); oi = original.Length; pi = patched.Length; break;
                }
                throw new InvalidDataException("Metin alani hizalanamadi: " + diffO);
            }
            output.Write(patched, pi, spFound - pi);
            byte[] length = BitConverter.GetBytes(newSize); output.Write(length, 0, 4);
            output.Write(newRaw, 0, newRaw.Length);
            for (int i = 0; i < ((-newSize) & 3); i++) output.WriteByte(0);
            oi = soFound + 4 + oldSize + oldPad;
            pi = spFound + 4 + newSize + oldPad;
        }
        if (oi != original.Length || pi != patched.Length) throw new InvalidDataException("Nesne sonlari hizalanamadi.");
        return output.ToArray();
    }

    public static void PatchFile(string backup, string target, byte[] blob, long[] pids, int[] blobOffsets, int[] sizes, string[] kinds)
    {
        byte[] source = File.ReadAllBytes(backup);
        Asset asset = Parse(source);
        Dictionary<long, Obj> byPid = new Dictionary<long, Obj>();
        foreach (Obj o in asset.Objects) byPid[o.Pid] = o;
        Dictionary<long, byte[]> mods = new Dictionary<long, byte[]>();
        for (int i = 0; i < pids.Length; i++) {
            if (!byPid.ContainsKey(pids[i])) throw new InvalidDataException("Path ID bulunamadi: " + pids[i]);
            Obj o = byPid[pids[i]];
            byte[] supplied = new byte[sizes[i]]; Buffer.BlockCopy(blob, blobOffsets[i], supplied, 0, sizes[i]);
            if (kinds[i] == "i2source") mods[pids[i]] = supplied;
            else {
                byte[] original = new byte[o.Size]; Buffer.BlockCopy(source, asset.DataOffset + (int)o.Offset, original, 0, o.Size);
                mods[pids[i]] = RepairObject(original, supplied);
            }
        }

        List<Obj> ordered = new List<Obj>(asset.Objects);
        ordered.Sort(delegate(Obj x, Obj y) { return x.Offset.CompareTo(y.Offset); });
        MemoryStream data = new MemoryStream();
        long cursor = 0;
        foreach (Obj o in ordered) {
            if (o.Offset < cursor || asset.DataOffset + o.Offset + o.Size > source.LongLength) throw new InvalidDataException("Gecersiz nesne araligi.");
            int gap = checked((int)(o.Offset - cursor));
            data.Write(source, asset.DataOffset + checked((int)cursor), gap);
            int targetMod = (int)(o.Offset & 15);
            int pad = (targetMod - ((int)data.Position & 15)) & 15;
            for (int i = 0; i < pad; i++) data.WriteByte(0);
            byte[] raw;
            if (!mods.TryGetValue(o.Pid, out raw)) { raw = new byte[o.Size]; Buffer.BlockCopy(source, asset.DataOffset + (int)o.Offset, raw, 0, o.Size); }
            o.NewOffset = data.Position; o.NewSize = raw.Length; data.Write(raw, 0, raw.Length);
            cursor = o.Offset + o.Size;
        }
        data.Write(source, asset.DataOffset + checked((int)cursor), checked((int)(source.LongLength - asset.DataOffset - cursor)));
        byte[] rebuilt = data.ToArray();
        byte[] result = new byte[asset.DataOffset + rebuilt.Length];
        Buffer.BlockCopy(source, 0, result, 0, asset.DataOffset);
        Buffer.BlockCopy(rebuilt, 0, result, asset.DataOffset, rebuilt.Length);
        foreach (Obj o in asset.Objects) {
            if (asset.Version >= 22) W64(result, o.OffsetPos, o.NewOffset); else W32(result, o.OffsetPos, checked((int)o.NewOffset));
            W32(result, o.SizePos, o.NewSize);
        }
        if (asset.Version >= 22) W64BE(result, 24, result.LongLength);
        else { int n = checked(result.Length); result[4]=(byte)(n>>24); result[5]=(byte)(n>>16); result[6]=(byte)(n>>8); result[7]=(byte)n; }

        string temp = target + ".patching.tmp";
        File.WriteAllBytes(temp, result);
        if (File.Exists(target)) File.Replace(temp, target, null); else File.Move(temp, target);
    }
}
'@

Add-Type -TypeDefinition $source -Language CSharp
$index = Get-Content -LiteralPath $indexPath -Raw -Encoding UTF8 | ConvertFrom-Json
$blob = [System.IO.File]::ReadAllBytes($blobPath)
$flatIndex = @(foreach ($entry in $index) { $entry })
$groups = $flatIndex | Group-Object -Property file | Sort-Object -Property Name

Write-Host '============================================================'
Write-Host '  BLACKWOOD TURKCE YAMA v1.1 FIX'
Write-Host '============================================================'
Write-Host ('Oyun klasoru: ' + $gameRoot)
Write-Host ('Yamalanacak dosya: ' + $groups.Count)
Write-Host ''

foreach ($group in $groups) {
    $target = Join-Path $dataDir $group.Name
    $backup = $target + '.bak'
    if (-not (Test-Path -LiteralPath $target)) {
        Write-Host ('[ATLANDI] Bulunamadi: ' + $group.Name) -ForegroundColor Yellow
        continue
    }
    if (-not (Test-Path -LiteralPath $backup)) {
        [System.IO.File]::Copy($target, $backup, $false)
        Write-Host ('[YEDEK] ' + $group.Name)
    }
    $entries = @($group.Group)
    [long[]]$pids = @($entries | ForEach-Object { [long]$_.pid })
    [int[]]$offsets = @($entries | ForEach-Object { [int]$_.blob_off })
    [int[]]$sizes = @($entries | ForEach-Object { [int]$_.size })
    [string[]]$kinds = @($entries | ForEach-Object { [string]$_.kind })
    [BlackwoodPatch]::PatchFile($backup, $target, $blob, $pids, $offsets, $sizes, $kinds)
    Write-Host ('[TAMAM] {0} ({1} nesne)' -f $group.Name, $entries.Count)
}

Write-Host ''
Write-Host 'Kurulum basariyla tamamlandi. Oyunu baslatabilirsiniz.' -ForegroundColor Green
