#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BLACKWOOD Türkçe Yama — Kurulum Betiği
======================================
Kullanım:
    1. Bu dosyayı (kurulum.py) ve "yama" klasörünü oyunun ana dizinine kopyalayın.
       (Blackwood.exe'nin yanına — "yama" klasörü de aynı yerde olmalı)
    2. Şu komutu çalıştırın:  python kurulum.py
    3. Oyunu açın — metinler Türkçe!

Notlar:
- Orijinal dosyalar ".bak" uzantısıyla yedeklenir.
- Geri almak için: python kaldir.py
- Python 3.8+ gereklidir. Harici paket GEREKMEZ.
"""
import json
import os
import struct
import sys


class UnitySF:
    """Unity SerializedFile minimal parser + minimal-touch writer."""

    def __init__(self, data):
        self.data = data
        d = data
        self.version = struct.unpack_from(">I", d, 8)[0]
        self.file_size = struct.unpack_from(">I", d, 28)[0]
        self.data_offset = struct.unpack_from(">I", d, 36)[0]

        def cstr(pos):
            end = d.index(b"\x00", pos)
            return d[pos:end].decode("utf-8", "replace"), end + 1

        def skip_type(pos):
            (cls,) = struct.unpack_from("<i", d, pos); pos += 4
            if self.version >= 16:
                pos += 1
            if self.version >= 17:
                pos += 2
            if self.version >= 13:
                cond = (self.version < 16 and cls < 0) or (self.version >= 16 and cls == 114)
                if cond:
                    pos += 16
                pos += 16
            if self.enable_type_tree:
                (n, buf) = struct.unpack_from("<ii", d, pos)
                node = 24 if self.version >= 19 else 32
                pos += 8 + node * n + buf
                if self.version >= 21:
                    (nd,) = struct.unpack_from("<i", d, pos)
                    pos += 4 + 4 * nd
            return pos

        pos = 48
        _, pos = cstr(pos)
        pos += 4
        self.enable_type_tree = d[pos]; pos += 1
        (tc,) = struct.unpack_from("<i", d, pos); pos += 4
        for _ in range(tc):
            pos = skip_type(pos)
        (self.object_count,) = struct.unpack_from("<i", d, pos)
        table_start = pos
        pos += 4
        self.objects = []
        self.entry_raw = []
        for _ in range(self.object_count):
            e = pos
            pos = (pos + 3) & ~3
            (pid,) = struct.unpack_from("<q", d, pos); pos += 8
            if self.version >= 22:
                (bs,) = struct.unpack_from("<q", d, pos); pos += 8
            else:
                (bs,) = struct.unpack_from("<I", d, pos); pos += 4
            (sz,) = struct.unpack_from("<I", d, pos); pos += 4
            (tid,) = struct.unpack_from("<i", d, pos); pos += 4
            self.objects.append((pid, bs, sz, tid))
            self.entry_raw.append(d[e:pos])
        self.table_end = pos
        self.table_start = table_start

    def write(self, mods):
        d = self.data
        appended = bytearray()
        new_off = {}
        base = len(d) - self.data_offset
        for (pid, off, size, tid) in self.objects:
            if pid in mods:
                appended += b"\x00" * ((-len(appended)) % 4)
                rel = base + len(appended)
                raw = mods[pid]
                appended += raw
                new_off[pid] = (rel, len(raw), tid)
        t = bytearray()
        t += struct.pack("<i", self.object_count)
        i = 0
        for (pid, off, size, tid) in self.objects:
            if pid in new_off:
                no, ns, _ = new_off[pid]
            else:
                no, ns = off, size
            raw_e = self.entry_raw[i]; i += 1
            pad = len(raw_e) - (24 if self.version >= 22 else 20)
            t += b"\x00" * pad
            t += struct.pack("<q", pid)
            if self.version >= 22:
                t += struct.pack("<q", no)
            else:
                t += struct.pack("<I", no)
            t += struct.pack("<I", ns)
            t += struct.pack("<i", tid)
        assert len(t) == self.table_end - self.table_start
        metadata = d[48:self.table_start] + bytes(t) + d[self.table_end:self.data_offset]
        blob = bytearray(d[self.data_offset:])
        for (pid, off, size, tid) in self.objects:
            if pid in mods:
                blob[off:off + size] = b"\x00" * size
        total = self.data_offset + len(blob) + len(appended)
        hdr = bytearray(d[:48])
        struct.pack_into(">I", hdr, 28, total)
        return bytes(hdr) + metadata + bytes(blob) + bytes(appended)


def copy_file(src, dst):
    with open(src, "rb") as f, open(dst, "wb") as g:
        while True:
            chunk = f.read(8 * 1024 * 1024)
            if not chunk:
                break
            g.write(chunk)


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    yama_dir = os.path.join(here, "yama")
    idx_path = os.path.join(yama_dir, "patch_index.json")
    blob_path = os.path.join(yama_dir, "patch_blob.bin")

    game_root = None
    if os.path.isdir(os.path.join(here, "Blackwood_Data")):
        game_root = here
    elif len(sys.argv) > 1:
        game_root = sys.argv[1]
    if game_root is None or not os.path.isdir(os.path.join(game_root, "Blackwood_Data")):
        print("Oyun dizini bulunamadı. kurulum.py'yi Blackwood.exe'nin yanına koyun")
        print('veya yolu belirtin:  python kurulum.py "C:\\Oyunlar\\BLACKWOOD"')
        sys.exit(1)

    gd = os.path.join(game_root, "Blackwood_Data")
    idx = json.load(open(idx_path, encoding="utf-8"))
    blob = open(blob_path, "rb").read()
    by_file = {}
    for e in idx:
        by_file.setdefault(e["file"], []).append(e)

    print("=" * 60)
    print("  BLACKWOOD TÜRKÇE YAMA KURULUMU")
    print("=" * 60)
    print("Oyun dizini : " + gd)
    print("Yama        : %d nesne, %d dosya" % (len(idx), len(by_file)))
    print()

    ok = 0
    for fn in sorted(by_file):
        path = os.path.join(gd, fn)
        if not os.path.exists(path):
            print("  [ATLANDI] %s bulunamadı" % fn)
            continue
        bak = path + ".bak"
        if not os.path.exists(bak):
            print("  [YEDEK  ] %s" % fn)
            copy_file(path, bak)
        entries = by_file[fn]
        with open(path, "rb") as f:
            data = f.read()
        sf = UnitySF(data)
        mods = {}
        for e in entries:
            mods[e["pid"]] = blob[e["blob_off"]: e["blob_off"] + e["size"]]
        out = sf.write(mods)
        with open(path, "wb") as f:
            f.write(out)
        ok += 1
        print("  [TAMAM  ] %s: %d nesne" % (fn, len(entries)))

    print()
    print("Kurulum tamamlandı! (%d dosya)" % ok)
    print("Oyunu başlatın — metinler Türkçe görünecek.")
    print("Geri almak için: python kaldir.py")


if __name__ == "__main__":
    main()
