#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""BLACKWOOD Türkçe Yama — Kaldırma Betiği
Orijinal (.bak) dosyalarını geri yükler."""
import os
import sys


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    game_root = None
    if os.path.isdir(os.path.join(here, "Blackwood_Data")):
        game_root = here
    elif len(sys.argv) > 1:
        game_root = sys.argv[1]
    if game_root is None:
        print("Oyun dizini bulunamadı.")
        sys.exit(1)
    gd = os.path.join(game_root, "Blackwood_Data")

    n = 0
    for fn in os.listdir(gd):
        if fn.endswith(".bak"):
            orig = os.path.join(gd, fn[:-4])
            bak = os.path.join(gd, fn)
            if os.path.exists(orig):
                os.remove(orig)
            os.rename(bak, orig)
            n += 1
            print("geri yüklendi:", fn[:-4])
    print("Kaldırma tamamlandı. (%d dosya)" % n)


if __name__ == "__main__":
    main()
