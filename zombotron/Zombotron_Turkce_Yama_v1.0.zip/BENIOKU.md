# Zombotron Türkçe Yama - Kurulum

1. Oyunun kurulu olduğu klasörü açın (`Zombotron`).
2. `Zombotron_Data\resources.assets` dosyasının yedeğini alın.
3. Yamadaki `resources.assets` dosyasını `Zombotron_Data` içine kopyalayın, üzerine yazın.
4. Oyunu açın, dil İngilizce kalsın. Menüler ve yazılar Türkçe görünür.
5. Eski hale dönmek için yedeklediğiniz dosyayı geri kopyalayın.
